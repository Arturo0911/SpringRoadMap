package com.company.socialnetwork.SocialNetworkMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialNetworkMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
