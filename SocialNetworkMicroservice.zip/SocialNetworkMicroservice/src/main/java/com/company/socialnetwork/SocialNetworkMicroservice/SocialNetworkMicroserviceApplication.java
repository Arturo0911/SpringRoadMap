package com.company.socialnetwork.SocialNetworkMicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialNetworkMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialNetworkMicroserviceApplication.class, args);
	}

}
