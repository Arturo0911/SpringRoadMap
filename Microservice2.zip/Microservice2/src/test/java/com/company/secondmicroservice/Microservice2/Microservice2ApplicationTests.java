package com.company.secondmicroservice.Microservice2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Microservice2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
