package com.company.rest.college.CollegeMicroService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
