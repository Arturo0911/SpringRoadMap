package com.company.rest.college.CollegeMicroService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeMicroServiceApplication.class, args);
	}

}
