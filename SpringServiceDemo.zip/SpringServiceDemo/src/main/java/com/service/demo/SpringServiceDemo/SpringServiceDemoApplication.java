package com.service.demo.SpringServiceDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringServiceDemoApplication.class, args);
	}

}
